import serial
import matplotlib.pyplot as plt
import time

# Configura el puerto serial
ser = serial.Serial('COM3', 115200)  # Reemplaza 'COM3' con el puerto correspondiente y 115200 con la tasa de baudios de tu STM32

# Función para leer los datos desde el puerto serial
def read_serial_data():
    line = ser.readline().decode('utf-8').strip()  # Leer una línea, decodificarla y eliminar saltos de línea
    try:
        return float(line)  # Convertir a flotante si es posible
    except ValueError:
        return None  # Si el valor no es numérico, ignorarlo

# Inicializa la ventana gráfica
plt.ion()  # Modo interactivo para graficar en tiempo real
fig, ax = plt.subplots()
x_data, y_data = [], []  # Listas para almacenar los datos de tiempo y los datos seriales

start_time = time.time()

# Configura los límites iniciales del gráfico
ax.set_xlim(0, 1000)  # Límite inicial del eje X
ax.set_ylim(0, 6000)  # Ajusta según el rango esperado de tus datos

line, = ax.plot(x_data, y_data, '-')  # Gráfica continua sin puntos

while True:
    data = read_serial_data()  # Lee el valor desde el puerto serial
    if data is not None:
        current_time = time.time() - start_time  # Tiempo desde el inicio

        # Añadir los nuevos datos
        x_data.append(current_time)
        y_data.append(data)

        # Actualizar los límites del eje X para que se expanda a medida que llegan más datos
        ax.set_xlim(0, current_time + 1)

        # Actualizar la gráfica
        line.set_xdata(x_data)
        line.set_ydata(y_data)
        plt.draw()
        plt.pause(0.01)  # Pausa pequeña para actualizar la gráfica
